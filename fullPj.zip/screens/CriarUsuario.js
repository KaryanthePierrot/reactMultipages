import React, { useEffect, useState } from 'react';

import {
    View,
    Text,
    TextInput,
    Button,
    FlatList,
    StyleSheet
} from 'react-native';

import {
    createTb,
    createUsers,
    showUsers,
    updateUser,
    delUser
} from '../database/bd';

export default function CriarUsuario() {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [users, setUsers] = useState([]);
    const [modoEdicao, setModoEdicao] = useState(false);
    const [idAtual, setIdAtual] = useState(null);

    useEffect(() => {
        async function iniciar() {
            await createTb();
            await carregarUsers();
        }
        iniciar();
    }, []);

    async function carregarUsers() {
        const usuarios = await showUsers();
        setUsers(usuarios);
    }

    async function salvar() {
        if (modoEdicao) {
            await updateUser(idAtual, username, password);
            setModoEdicao(false);
            setIdAtual(null);
        } else {
            await createUsers(username);
        }
        setUsername('');
        setPassword('');
        await carregarpassword();
    }

    function editar(user) {
        setUsername(user.username);
        setPassword(user.password);
        setIdAtual(user.id);
        setModoEdicao(true);
    }

    async function excluir(id) {
        await delUser(id);
        await carregarUsers();
    }

    return (
        <View style={estilos.app}>
            <Text style={estilos.username}>Usuário</Text>
            <TextInput
                style={estilos.input}
                placeholder="Digite um Username"
                value={username}
                onChangeText={setUsername}
            />
            <TextInput
                style={estilos.input}
                placeholder="Digite uma Senha"
                value={password}
                onChangeText={setPassword}
            />
            <Button title={modoEdicao ? "Atualizar" : "Adicionar"}
                onPress={() => [salvar,
                    navigation.navigate('HomeScreen')]}/>

            <FlatList
                data={users}
                keyExtractor={(item) => item.id.toString()}
                renderItem={({ item }) => (
                    <View style={estilos.item}>
                        <Text>{item.username}</Text>
                        <Text>{item.password}</Text>
                        <View style={estilos.botoes}>
                            <Button title="Editar" onPress={() => editar(item)} />
                            <Button title="Excluir" onPress={() => excluir(item.id)} />
                        </View>
                    </View>
                )}
            />
        </View>
    );
}
const estilos = StyleSheet.create({
    Login: {
        flex: 1,
        padding: 20,
        paddingTop: 50
    },

    username: {
        fontSize: 24,
        marginBottom: 10
    },

    input: {
        borderWidth: 1,
        borderColor: '#ccc',
        padding: 8,
        marginBottom: 10
    },

    item: {
        padding: 10,
        borderBottomWidth: 1,
        borderBottomColor: '#ccc'
    },
    botoes: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        marginTop: 5
    }
}); 