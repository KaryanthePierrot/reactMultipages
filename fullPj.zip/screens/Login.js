import React, { useEffect, useState } from 'react';

import {
    View,
    Text,
    TextInput,
    Button,
    FlatList,
    StyleSheet
} from 'react-native';

import {
    createTb,
    showUsers,
    delUser
} from '../database/bd';

export default function Login({navigation}){

    return(
        <View style={styles.container}>
            <Text style={styles.text}>Logar</Text>
            <Button title="Logar" onPress={() => navigation.navigate('HomeScreen')} />
        </View>
    );
}