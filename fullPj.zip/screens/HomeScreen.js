import React from 'react';
import { View, Text, Button, StyleSheet } from
    'react-native';


export default function HomeScreen({ navigation }) {
    return (
        <View style={styles.container}>
            <Text style={styles.text}>Tela Inicial</Text>
            <Button
                title="Ir para Detalhes"
                onPress={() =>
                    navigation.navigate('Details')}
            />

            <Text style={styles.text}>Tela de Frases</Text>
            <Button
                title="Ir ver Frases"
                onPress={() =>
                    navigation.navigate('Frases')}
            />

            <Text style={styles.text}>Tela de IMC</Text>
            <Button
                title="Ir Consultar o IMC"
                onPress={() =>
                    navigation.navigate('IMC')}
            />
        </View>
    );
}
const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    text: {
        fontSize: 24,
    },
});
