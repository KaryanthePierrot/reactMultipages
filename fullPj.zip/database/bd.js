import * as SQLite from 'expo-sqlite';
let banco;
export async function conn() {
    if (!banco){
        banco = await SQLite.openDatabaseAsync('useColorScheme.db');
        await banco.execAsync(`PRAGMA journal_mode = WAL`);

    }
    return banco;
}


export async function createTb() {
 const db = await conn();
 await db.execAsync(`
    CREATE TABLE IF NOT EXISTS users ( id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    password TEXT NOT NULL,
    )
    `)
}
export async function createUsers(username, password) {
const db= await conn();
const resultado = await db.runAsync(
    'INSERT INTO users(username, password) VALUES(?,?);', username, password
);
return resultado.lastInsertRowId
}

export async function showUsers() {
    const db = await conn();
    const users = await db.getAllAsync('SELECT * FROM users;');
}

export async function showUser(id) {
    const db = await conn();
    const user = await db.getAllAsync('SELECT * FROM users WHERE user = ?;', id);
}

export async function updateUser(id, newUsername, newPassword) {
    const db = await conn();
    await db.runAsync(
        'UPDATE users SET username = ?, password = ? WHERE id = ?;',
        newUsername, newPassword, id
    );
}

export async function delUser(id) {
    const db = await conn();
    await db.runAsync(
            'DELETE FROM users WHERE id = ?;',
            id
    );
}