import * as React from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import HomeScreen from './screens/HomeScreen';
import DetailsScreen from './screens/DetailsScreen';
import Frases from './screens/GeraFrases';
import IMC from './screens/IMC';
// import CriarUsuario from './screens/CriarUsuario';
// import Login from './screens/login';\

export default function App() {
  const Stack = createNativeStackNavigator();
  return (
    <NavigationContainer>
      <Stack.Navigator>
        <Stack.Screen name="Home" component={HomeScreen} />
        <Stack.Screen name="Frases" component={Frases} />
        <Stack.Screen name="Details" component={DetailsScreen} />
        <Stack.Screen name="IMC" component={IMC} />
      </Stack.Navigator>
    </NavigationContainer>
  );




}